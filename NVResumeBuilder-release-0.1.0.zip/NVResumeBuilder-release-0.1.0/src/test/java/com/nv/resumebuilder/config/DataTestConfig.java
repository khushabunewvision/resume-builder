package com.nv.resumebuilder.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Profile("data")
@Configuration
public class DataTestConfig {
}

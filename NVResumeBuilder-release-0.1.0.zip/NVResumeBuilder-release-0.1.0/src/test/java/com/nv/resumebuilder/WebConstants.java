package com.nv.resumebuilder;

public interface WebConstants
{
    String VIEW_PREFIX = "/WEB-INF/jsp/";
    String VIEW_SUFFIX = ".jsp";
}

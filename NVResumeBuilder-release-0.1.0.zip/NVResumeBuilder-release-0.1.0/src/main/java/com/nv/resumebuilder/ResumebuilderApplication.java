package com.nv.resumebuilder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResumebuilderApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResumebuilderApplication.class, args);

	}   
}

package com.nv.resumebuilder.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//import java.sql.Date;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrganizationalDetailsModel {
	private String comName;
	private String designation;
	private String date;

	

	
}

package com.nv.resumebuilder.service;

import com.nv.resumebuilder.entity.PersonalDetailsEntity;

public interface PersonalDetailsServices {
	public PersonalDetailsEntity savePersonalDetails(PersonalDetailsEntity personalDetailsEntity);

	public PersonalDetailsEntity findById(Long theId);

}

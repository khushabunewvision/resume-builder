package com.nv.resumebuilder.repository;


// please to chanage in this folder

public class Dao {

}
